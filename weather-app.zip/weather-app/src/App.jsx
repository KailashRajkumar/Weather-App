import React from 'react'
import './App.css';
import SearchWeather from './components/SearchWeather';

const App = () => {
  return (
    <div>
      <SearchWeather />  
    </div>
  )
}

export default App